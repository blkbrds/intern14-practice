//
//  Calculator.swift
//  BaiTapMVC
//
//  Created by PCI0001 on 7/4/19.
//  Copyright © 2019 PCI0001. All rights reserved.
//

import UIKit

class Calculator: UIViewController {
    @IBOutlet private weak var screenLabel: UILabel!
    @IBOutlet private var numberButton: [UIButton]!
    @IBOutlet private var operatorButton: [UIButton]!
    @IBOutlet private weak var acButton: UIButton!
    @IBOutlet private weak var equalButton: UIButton!
    
    var numberOnScreen: Double = 0
    var result: Double = 0
    var stack: [Double] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        acButton.layer.borderWidth = 1
        acButton.layer.cornerRadius = acButton.frame.width / 2
        equalButton.layer.borderWidth = 1
        equalButton.layer.cornerRadius = equalButton.frame.width / 2
        screenLabel.layer.borderWidth = 2
        
        for i in numberButton {
            i.layer.borderWidth = 1
            i.layer.cornerRadius = i.frame.width / 2
        }
        
        for i in operatorButton {
            i.layer.borderWidth = 1
            i.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1).cgColor
            i.layer.cornerRadius = i.frame.width / 2
        }
    }
    
    @IBAction func numberButtonTouchUpInside(_ sender: UIButton) {
        numberOnScreen = numberOnScreen * 10 + Double(sender.tag - 1)
        screenLabel.text = String(numberOnScreen)
    }
    
    @IBAction func operatorButtonTouchUpInside(_ sender: UIButton) {
        if stack.isEmpty {
            stack.append(numberOnScreen)
            numberOnScreen = 0
        } else {
            if sender.tag == 11 {
                result = stack[0] + numberOnScreen
                
            } else if sender.tag == 12 {
                result = stack[0] - numberOnScreen
            }
            numberOnScreen = 0
            screenLabel.text = String(result)
            stack.removeAll()
        }
        
        
//        stack.append(numberOnScreen)
//        if sender.tag == 11 { //Add
//            result = stack[0] + stack[1]
//            print(result)
//            screenLabel.text = String(result)
//            stack.append(result)
//            stack.removeSubrange(0...1)
//            print(stack)
//            numberOnScreen = 0
//        } else if sender.tag == 12 { //Subtract
//            result = stack[0] - stack[1]
//            print(result)
//            screenLabel.text = String(result)
//            stack.append(result)
//            stack.removeSubrange(0...1)
//            print(stack)
//            numberOnScreen = 0
//        }
    }
    
    @IBAction func acButtonTouchUpInside(_ sender: UIButton) {
        screenLabel.text?.removeAll()
        numberOnScreen = 0
        result = 0
        stack.removeAll()
    }
    
    @IBAction func equalButtonTouchUpInside(_ sender: UIButton) {
        
    }

}
