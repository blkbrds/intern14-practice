//
//  ViewController.swift
//  BaiTapMVC
//
//  Created by PCI0001 on 7/3/19.
//  Copyright © 2019 PCI0001. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

